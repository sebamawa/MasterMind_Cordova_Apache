function jugar(modoJuego, tipoCodigo, dificultad){
    
}


